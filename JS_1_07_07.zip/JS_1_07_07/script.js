/*
console.log(5454); // вывод данных в консоль
let userName = 'Ivan9999';
console.log(userName);
*/

/*
let age = 33;
let newAge = age + 5;

console.log(newAge);
*/

/*
let cats = 2;
let dogs = 7;

let animals = cats + dogs;

console.log(animals);*/

/*
let age = 22;
age = age + 1;
age = age + 5;

console.log(age);*/

/*
let age = 22;
// age = age + 1;
// age += 1;

age = age + 10;
age += 10;
age -= 10;

console.log(age);*/

/*
let age = 22;
age = age + 1;
age += 1;
age++;// инкремент
age--;// вычитаем 1, декремент

console.log(age);*/

/*
const age = 22;
age = age + 1;
*/

/*
let firstName = 'Иван';
let lastName = "Иванов";
let sureName = `Иванович`;

console.log(firstName[0]);
console.log(firstName.length);// длина строки
console.log(firstName.toUpperCase());// перевод строки в верхний регистр*/


/*
let firstName = 'Иван';

// let message = "Привет, " + firstName + ".";// конкатенация строк
let message = `Привет, ${firstName}.`;

console.log(message);*/

/*
let firstName = 'Петр';
let lastName = 'Петров';

let message = `Меня зовут ${firstName}, фамилия моя ${lastName}.`;

console.log(message);*/

/*
let firstName = 'Анна';
let lastName = 'Петрова';

let message = `
    <h2>Имя: ${firstName}</h2>
    <p>Фамилия: ${lastName}</p>
`;

document.write(message);// вывод строки в документ
*/

/*
let age;
console.log(age);

let userName = 'Ivan';
console.log(userName[8]);*/